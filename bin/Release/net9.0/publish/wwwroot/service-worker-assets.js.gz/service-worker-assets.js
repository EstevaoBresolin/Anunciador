self.assetsManifest = {
  "version": "zeWSjJcB",
  "assets": [
    {
      "hash": "sha256-LoGIGNjKzpPYd/CuPNcoe46XPkqmix6w2YumcPOL9gg=",
      "url": "AnunciadorV1.styles.css"
    },
    {
      "hash": "sha256-qLk+rdoDNG7HaAS3Ktu2G6qkXr5ZwXYV41YReZpFZ6U=",
      "url": "Imagens/rosto.png"
    },
    {
      "hash": "sha256-rrDAXDYtwYgcTE9UL3VsH7DpUE8tYIEc77BxS5ZipFQ=",
      "url": "Imagens/rosto2.png"
    },
    {
      "hash": "sha256-KeMyJ5FhRt36bcP6HrAdczhAkvRRUTOIAGVZJ2Iit+o=",
      "url": "Imagens/rosto3.png"
    },
    {
      "hash": "sha256-RSB/JgAoSTBYZr+4NZpCGFL8E8yP6Xt2tpkf+RiBu6I=",
      "url": "Imagens/rosto4.png"
    },
    {
      "hash": "sha256-o5ZEqYQxLrgANxg4a5a7GUqoq6A2h6UpXGmJTVkXnbc=",
      "url": "Imagens/rosto5.png"
    },
    {
      "hash": "sha256-hzx3FeYu7VeScONShpbENB4zR67g5oGiT7AivYOQhss=",
      "url": "_content/MudBlazor.ThemeManager/MudBlazorThemeManager.css"
    },
    {
      "hash": "sha256-d1ee8m8CKXHLkW0DDwn00o/ghDNhscMVl/ei7IzThfU=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-Y5zCtrV6/XngfIAwnKZESn//G3w6zwlrDewTKl6fojQ=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-ebRCoEIt95F9eYSky2XgRs70W/XcGawlswV83MN1vmU=",
      "url": "_framework/AnunciadorV1.9keby500ah.wasm"
    },
    {
      "hash": "sha256-6TjAnwK83qx2u7jJRERCUpe4alFqntX4/M0Mk/AXYRA=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.p4cmqynr10.wasm"
    },
    {
      "hash": "sha256-359/0cPUCseKVWbwcSRtdwuuJ4bCYL8gP35yCzeSWHc=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.t9gvcwb1a5.wasm"
    },
    {
      "hash": "sha256-Rq0IHUvYMN8nxN5rYdTDrVZU7IMGZ4eB++aid1m6T+M=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.259gvbp8ry.wasm"
    },
    {
      "hash": "sha256-UBFYLOk/2kkdAdC+SoEZNlGkzOjvDSoX1EU3EBlEFLk=",
      "url": "_framework/Microsoft.AspNetCore.Components.wgzzvdufst.wasm"
    },
    {
      "hash": "sha256-yxPiW+l2bwpbqQMt+LqIVyoudbaoHWuYPnD4DDJUr88=",
      "url": "_framework/Microsoft.Extensions.Configuration.7p4o2tpul4.wasm"
    },
    {
      "hash": "sha256-Vaey6KNbQjvV5f4sgTb9Z7DpC7i8fKGaG8HGFaV0O8k=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.79qfazjlcu.wasm"
    },
    {
      "hash": "sha256-e7KqvUYccR78CImWVq5kLp49gK7pPVNLuAnrrJ59tXE=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.lo1485j0el.wasm"
    },
    {
      "hash": "sha256-e8G0JQI0dUUudPzWdfamVDGrSV+tqr50McBL0FMtaGo=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.3ynt3oix6u.wasm"
    },
    {
      "hash": "sha256-HVCVSm+gu7piiScfqaxwFM3d8G2u6KsHu0eJe4U5vXs=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.lup1r7ebaf.wasm"
    },
    {
      "hash": "sha256-tnMHqb6BpI1Jj9M9WNSAAJzzxHrQgov/aSXbFqc+xzk=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.ixsppbtym0.wasm"
    },
    {
      "hash": "sha256-6UgMJoVZBfDdfzYR0aKVK6BWArxpXC1qiQDDjiXw/L4=",
      "url": "_framework/Microsoft.Extensions.Localization.bvn14pws96.wasm"
    },
    {
      "hash": "sha256-Gc7Oqk4/9MAtp0l7ESF6JgqIYusSvnbJXnLHUhPW9FY=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.5layk8frqd.wasm"
    },
    {
      "hash": "sha256-Rw3p7P7cbetsRUa1O+Q7ltdFAmR7kf26guR3xO9aq3s=",
      "url": "_framework/Microsoft.Extensions.Logging.fugc9tzrx1.wasm"
    },
    {
      "hash": "sha256-720xjccNSC/ixI8d5toBVmd5GGEzQAIN2LMqBmflaJw=",
      "url": "_framework/Microsoft.Extensions.Options.1cu2gj5cau.wasm"
    },
    {
      "hash": "sha256-kvH0PWaEihTjfJSm4b+K3UHAQau8H9u9OsWrrZj/Chw=",
      "url": "_framework/Microsoft.Extensions.Primitives.mytv1lpnrg.wasm"
    },
    {
      "hash": "sha256-sGms9Oai1ztzgfMsqBvmeKwa5ZyGWr/AEXr6thw0lso=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.8eb000j8w7.wasm"
    },
    {
      "hash": "sha256-xtQtSoK56ZLcZdr1TPIw4dex5O90dyRzRhWC9Coj9J8=",
      "url": "_framework/Microsoft.JSInterop.agnux60n3l.wasm"
    },
    {
      "hash": "sha256-E/StGV3uwcrkkRLS++3ssO5yI0Kt3VajHSR8kL2sDVg=",
      "url": "_framework/MudBlazor.t0h76d6tpu.wasm"
    },
    {
      "hash": "sha256-ByV+eHVYB+kFVK/j2S20AUuGG/loUissb+lvZgok9oM=",
      "url": "_framework/System.Collections.Concurrent.bvq4cqhiul.wasm"
    },
    {
      "hash": "sha256-NKz2Zq4Zi+BwGs8/MwZ4UhBtaPR8ht4F4xTxm6iHj3E=",
      "url": "_framework/System.Collections.Immutable.glj486dvh2.wasm"
    },
    {
      "hash": "sha256-VzgivupkSO0t77My464iX1po6ZyfKPapMC/5bqNk3pk=",
      "url": "_framework/System.Collections.bv3rwb81b1.wasm"
    },
    {
      "hash": "sha256-JNR/o2tUFaDeOk9pghPZD2sAdWEKA2OUJ2ONln9UeD0=",
      "url": "_framework/System.ComponentModel.076m38u6l8.wasm"
    },
    {
      "hash": "sha256-0zPcU/SK7S/lH4xT+MvpZEz3WiNzE82scvs7NkAc68Q=",
      "url": "_framework/System.ComponentModel.Annotations.5ao9lxtnjx.wasm"
    },
    {
      "hash": "sha256-hHiZmO1jFJy0Uj6B7injAuPP0jk3eb6f1m0XVJq/E1g=",
      "url": "_framework/System.ComponentModel.Primitives.csk5zzqafi.wasm"
    },
    {
      "hash": "sha256-yMH8bdXd9yb/0Fa/Nlj36eb0EFJ8R/DYM1rm+/Ug7LU=",
      "url": "_framework/System.ComponentModel.TypeConverter.gyqfsnzerd.wasm"
    },
    {
      "hash": "sha256-UvcRtsdIA/Mjrvcias0xJd/vMEkJK9pvJGEu2awDUd4=",
      "url": "_framework/System.Console.u93jk7h1j2.wasm"
    },
    {
      "hash": "sha256-uEVVMYx7abWgasKfPzSB6wOMoCpVEVv4EcEAOCa4ph0=",
      "url": "_framework/System.IO.Pipelines.0uhw8kopg1.wasm"
    },
    {
      "hash": "sha256-ExkFBhhRocXtbxUn8s0KHjv+roigmFTGm7pW10XWWvI=",
      "url": "_framework/System.Linq.Expressions.hznqjyv1ee.wasm"
    },
    {
      "hash": "sha256-1rdJcp+jfUHrF8hKEsWpRruaVm/Sm7F2+LYywr391SA=",
      "url": "_framework/System.Linq.e33i0mhhdg.wasm"
    },
    {
      "hash": "sha256-tCznIAaQdysSsBlri4JhpkOJQ4Nhsopc01TKAJP/ByY=",
      "url": "_framework/System.Memory.gxk30wm3qo.wasm"
    },
    {
      "hash": "sha256-IwGUdCFT/bTrVsSeM+GH+p7lNj/QctorMQ3XHOM4lus=",
      "url": "_framework/System.Net.Http.xjt5e7pw25.wasm"
    },
    {
      "hash": "sha256-nB5JS/nQn/pNhPGXYrb1uDoDn3cuo9TQKE1RKnVa648=",
      "url": "_framework/System.Net.Primitives.8x3nzqo64g.wasm"
    },
    {
      "hash": "sha256-8tBz+GN0TPvU205OThbWUGNOvSBXFEyYs11ymezgh5U=",
      "url": "_framework/System.ObjectModel.62kyprpgve.wasm"
    },
    {
      "hash": "sha256-HQaeZOEVqGqrO8IQneezTl0p0/BBR+/BYBjsT0d8FBk=",
      "url": "_framework/System.Private.CoreLib.jgxedf1mq2.wasm"
    },
    {
      "hash": "sha256-0ryBEg9heDsCjyob0pAFmF4vRRy3RQ4zsaHMr9wEHI4=",
      "url": "_framework/System.Private.Uri.m7cwnwwnnu.wasm"
    },
    {
      "hash": "sha256-SpoN2xLogk3gRLjVk2YpD0oc+LXCoyY5gBxF7REClH8=",
      "url": "_framework/System.Runtime.60juyq2uzt.wasm"
    },
    {
      "hash": "sha256-t5fC5E2r9YJ+puOWw7YuXXMwvd7LxeR0Zt16THexNM0=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.zp9u3yqbi4.wasm"
    },
    {
      "hash": "sha256-KD5saNzkpUD3A/RXlqBthi/qKA3Sk2nZuNvyfL9+EWc=",
      "url": "_framework/System.Text.Encodings.Web.wmi2z5c0zd.wasm"
    },
    {
      "hash": "sha256-C0tmYARQzxlLblw1mth/YacBb5BBHQxISVbwE0vcoeo=",
      "url": "_framework/System.Text.Json.r0v0ugxuew.wasm"
    },
    {
      "hash": "sha256-PEYZFqHFoi7KmiYeu7oGX+DPg2k3mcAg3n0RVsFbIX0=",
      "url": "_framework/System.Text.RegularExpressions.sq4rhiry1x.wasm"
    },
    {
      "hash": "sha256-F5PSI/gBuwoWEF7SbdO7+2/Lo9hw0ISBKug8avOpxP0=",
      "url": "_framework/System.Threading.vuopdrx302.wasm"
    },
    {
      "hash": "sha256-v1DeJU321NUwk3KJ0Lf8lQA3zwRfrxNommmMBs1s3Gk=",
      "url": "_framework/System.f0fr8djds0.wasm"
    },
    {
      "hash": "sha256-vbLdd9qlhnBnAGy/DzmyNS+o7iIqPCHPsGFhXxE9dYA=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-5TAd2is0AgjjYIAuEN8Bd5ZPoTk8dKE9RRtIQr4H5Lw=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-89jyB8DlCnV2BPMV477jOe1Sm0WXwVf8RuoSPsj4Ym8=",
      "url": "_framework/dotnet.native.3c4wvb350q.wasm"
    },
    {
      "hash": "sha256-LX9rFEWGVxhkOkAVPG0w5RxPwzPBlEUz6dQNjWS7M+M=",
      "url": "_framework/dotnet.native.hvg7u8bimp.js"
    },
    {
      "hash": "sha256-dCmS9Zx4egtLYSUgTI3R6gMS+Yg8MkzxW1CgEMJKAEw=",
      "url": "_framework/dotnet.runtime.cymp1amu5g.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-vGbjgqEqv4y3q5OB8W2R9LthkuF8mQfHFeNdKSReSmU=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DYpFkxrpgtlymDu4sUIErvAHNNLym/qggcaZpQF6mgs=",
      "url": "firebase.js"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-BjVJMwq2dSunjAMgZTqDA0ysB0Iodzyt/hqvK154zmg=",
      "url": "index.html"
    },
    {
      "hash": "sha256-f4c8YV1qrr6RSiVYWMQT7R5W2OkT+iXmE5H69/uRvGQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css"
    },
    {
      "hash": "sha256-xAT+n25FE5hvOjj2fG4YdOwr1bl4IlAJBNg6PbhLT2E=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css.map"
    },
    {
      "hash": "sha256-hN2ttMG/K3wQlFrN3SbQ1YF4tIJHCE4oYP+QibT3vOY=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css"
    },
    {
      "hash": "sha256-kgL+xwVmM8IOs15lnoHt9daR2LRMiBG/cYgUPcKQOY4=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css.map"
    },
    {
      "hash": "sha256-M15fHTKfMK6cTars5c28PNhN6hD0qeUb3HPzOdoPwCc=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css"
    },
    {
      "hash": "sha256-/siQUA8yX830j+cL4amKHY3yBtn3n8z3Eg+VZ15f90k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css.map"
    },
    {
      "hash": "sha256-+rGG3u63SMkHL80Ga42LAawPUj7i8vaR2Kuenqlta2E=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css"
    },
    {
      "hash": "sha256-7GdOlw7U/wgyaeUtFmxPz5/MphdvVSPtVOOlTn9c33Q=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css.map"
    },
    {
      "hash": "sha256-rjusxCRzKjztCcfgOVduAc3e3Z7KvimJGokJSeADNmE=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css"
    },
    {
      "hash": "sha256-RXJ/QZiBfHXoPtXR2EgC+bFo2pe3GtbZO722RtiLGzQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css.map"
    },
    {
      "hash": "sha256-y72bT5TKmFmfvw3bNEzPRNZa/8595xtseZIcBUV0PdM=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css"
    },
    {
      "hash": "sha256-0eqVT62kqRLJh9oTqLeIH4UnQskqVjib8hl2fXxl4lg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css.map"
    },
    {
      "hash": "sha256-gRKIHVkBgnCPUs/hmZsXynZ9ZJpvsE77idtljDkrWGI=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css"
    },
    {
      "hash": "sha256-OoQVwh7Arp7bVoK2ZiTx2S//KrnPrSPzPZ93CqCMhe8=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css.map"
    },
    {
      "hash": "sha256-UkajePbMzGj8y73Imkd3dWWnLJr0v2CrBCLMrVMleP8=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css"
    },
    {
      "hash": "sha256-910zw+rMdcg0Ls48ATp65vEn8rd5HvPxOKm2x3/CBII=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css.map"
    },
    {
      "hash": "sha256-uIzOR4gILoNjCGNryIsWnkEGO3BSwRa/MLjr73tDodE=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css"
    },
    {
      "hash": "sha256-Nfjrc4Ur9Fv2oBEswQWIyBnNDP99q+LhL+z9553O0cY=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css.map"
    },
    {
      "hash": "sha256-ZBXbYF8OZrF1GDOLMLvW/zRPtx1RfeMDYj5D2Wb/9jo=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css"
    },
    {
      "hash": "sha256-rHDmip4JZzuaGOcSQ1QSQrIbG0Eb3Zja9whqSF1zYIU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css.map"
    },
    {
      "hash": "sha256-MwFckg8YbY2WrveNQnXkfULkprYhFOq+t1BH92A7GsI=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css"
    },
    {
      "hash": "sha256-p0BVq5Ve/dohBIdfbrZsoQNu02JSsKh1g0wbyiQiUaU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css.map"
    },
    {
      "hash": "sha256-7MYEMUFgHEc1CjrfAK/TlV30POxgoxXk2b+vAs/143U=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css"
    },
    {
      "hash": "sha256-o8XK32mcY/FfcOQ1D2HJvVuZ0YTXSURZDLXCK0fnQeA=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css.map"
    },
    {
      "hash": "sha256-CzmECrtXV8BSk/+8SG+Rw7Fr+3hCt2bS2bEkS4YD3PQ=",
      "url": "lib/bootstrap/dist/css/bootstrap.css"
    },
    {
      "hash": "sha256-KzNVR3p7UZGba94dnCtlc6jXjK5urSPiZ/eNnKTmDkw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css.map"
    },
    {
      "hash": "sha256-sKIQRfQriISuQ9l/44b1zHfQniGXJhGonVtB2LlSuIs=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css"
    },
    {
      "hash": "sha256-8SM4U2NQpCLGTQLW5D/x3qSTwxVq2CP+GXYc3V1WwFs=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-/rceNUMI0RlFJugRzjua815bgXwawEJBGBPh4Vx3r38=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css"
    },
    {
      "hash": "sha256-3bYWUiiVYMZfv2wq5JnXIsHlQKgSKs/VcRivgjgZ1ho=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css.map"
    },
    {
      "hash": "sha256-rI1w2GDxZPCr77bpZIGQ8mUvMVtEr+gBtahl5RIPJpA=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css"
    },
    {
      "hash": "sha256-rTzXlnepcb/vgFAiB+U7ODQAfOlJLfM3gY6IU7eIANk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css.map"
    },
    {
      "hash": "sha256-VOWaQZMpqEcOWDedqMCUkMHpTWJxX3QyhQLbTkdnIrs=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js"
    },
    {
      "hash": "sha256-RjGMZhyiJvK/Ks90a5TcvlRXYTHtpHYVA7aSVO2OmwQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js.map"
    },
    {
      "hash": "sha256-6zfk2L8R3wCgRbZzpkEi7UYC2bc6fYGIgFfNeqyOWnQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-+xRrtnFdXma5KnnvCSkrj0rNglA6eDmmzgfU8WmlKIk=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-8qSnnwaKQ7IrcahFnti0q/a9s4Mor72Omb+S3p8lons=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js"
    },
    {
      "hash": "sha256-GHNXIeGA3sR+fJ6VxxG6xM98Zjwn7Z6ox2bYnESYMlo=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js.map"
    },
    {
      "hash": "sha256-REjSeieVKd00nAKwd6dv7MMhuVKvKctPmLI4iDRs/cc=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js"
    },
    {
      "hash": "sha256-JKsnNEN5AaoU643mpYb4ltQV3akQEtjEs0kkUgVO7gQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js.map"
    },
    {
      "hash": "sha256-ck+KkcwjViTZrn1geA3Jl3c9qHRdIJ6CY0KFsu67M1c=",
      "url": "lib/bootstrap/dist/js/bootstrap.js"
    },
    {
      "hash": "sha256-kuhcMzN694Yp3zEU/n+3vaLUEZuo0xU9zz+9OoIGSe0=",
      "url": "lib/bootstrap/dist/js/bootstrap.js.map"
    },
    {
      "hash": "sha256-aCTIqw9op0XQGYnNe1649V7fnihACD48OP3M8BP2xVM=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js"
    },
    {
      "hash": "sha256-678bgAJAhBVjYlX6/FXXv03u4hgVRKdOR8BIdrRd2Dw=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js.map"
    },
    {
      "hash": "sha256-agV5kVer4f4dm6a6M9m+BNfxzlFjIhkUzqrkXM8IATk=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-enKgCMkYmCpfEcmg6Annbmc40VZ/A6aYYSQjZfVn2cU=",
      "url": "sample-data/weather.json"
    }
  ]
};
